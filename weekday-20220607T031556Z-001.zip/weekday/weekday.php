<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>WeekDay using Switch Case</title>
</head>
<body>

<?php 
$num = 1;

switch ($num) {
	case 1:
		echo "monday";
		break;
	case 2:
		echo "tuesday";
		break;
	
	default:
		echo "Wrong input";
		break;
}
?>


</body>
</html>